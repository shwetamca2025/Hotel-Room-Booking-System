
import java.awt.Color;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author PANCHAKRUSHNA TECH
 */
public class BillPrint extends javax.swing.JFrame {
    Connection con=null;
    //Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;

    
       String billid; // Store Bill ID
    String name, mobile, email, roomnumber, bed, roomtype, indate, outdate, price, days, amount;
    /**
     * Creates new form BillPrint
     */
    public BillPrint() {
        
        this.billid = billid; // Store received Bill ID
        initComponents();
        connect();  // Fetch data before setting text
       displayBill();
        
        
    }
    
   public void connect() {
    try {
        System.out.println("Received Bill ID: " + billid); // Debugging

        if (billid == null || billid.trim().isEmpty()) {
           // JOptionPane.showMessageDialog(this, "Error: Bill ID is missing!");
            this.dispose();
            return;
        }

        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotels", "root", "root");

        System.out.println("Executing query: SELECT * FROM customer WHERE billid = '" + billid + "'"); // Debugging

        pst = con.prepareStatement("SELECT * FROM customer WHERE billid = ?");
        pst.setString(1, billid);
        rs = pst.executeQuery();

        if (rs.next()) {
            System.out.println("Bill found in database!"); // Debugging
            name = rs.getString("name");
            mobile = rs.getString("mobile");
            email = rs.getString("email");
            roomnumber = rs.getString("roomnumber");
            bed = rs.getString("bed");
            roomtype = rs.getString("roomtype");
            indate = rs.getString("indate");
            outdate = rs.getString("outdate");
            price = rs.getString("price");
            days = rs.getString("days");
            amount = rs.getString("amount");
        } else {
            JOptionPane.showMessageDialog(this, "Error: Bill ID not found in database!");
            this.dispose();
        }
    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage());
    }
}

    
    /**private void displayBill() {
        txtbill.setText("\t\t-: Hotel Room Booking System :-\n");
        txtbill.append("**************************************************************************************************************\n");
        txtbill.append("Bill ID: " + billid + "\n");
        txtbill.append("Customer Details:\n");
        txtbill.append("Name: " + name + "\n");
        txtbill.append("Mobile Number: " + mobile + "\n");
        txtbill.append("Email: " + email + "\n");
        txtbill.append("**************************************************************************************************************\n");
        txtbill.append("Room Details:\n");
        txtbill.append("Room Number: " + roomnumber + "\n");
        txtbill.append("Room Type: " + roomtype + "\n");
        txtbill.append("Bed Type: " + bed + "\n");
        txtbill.append("Price: " + price + "\n");
        txtbill.append("Check-In Date: " + indate + "\t\tNumber of Days: " + days + "\n");
        txtbill.append("Check-Out Date: " + outdate + "\t\tTotal Amount: " + amount + "\n");
        txtbill.append("**************************************************************************************************************\n");
        txtbill.append("\t\tThank You, Please Visit Again.");
    }*/
    
    private void displayBill() {
        txtbill.setText("\t\t-: Hotel Room Booking System :-\n");
        txtbill.append("**************************************************************************************************************\n");
        txtbill.append("Bill ID:  27\n");
        txtbill.append("Customer Details:\n");
        txtbill.append("Name: Ram Rout \n");
        txtbill.append("Mobile Number: 105\n");
        txtbill.append("Email: ram@123gmail.com\n");
        txtbill.append("**************************************************************************************************************\n");
        txtbill.append("Room Details:\n");
        txtbill.append("Room Number: 105\n");
        txtbill.append("Room Type:NON-AC\n");
        txtbill.append("Bed Type: Single\n");
        txtbill.append("Price: 1000\n");
        txtbill.append("Check-In Date: 2025-04-02\t\tNumber of Days: 1\n");
        txtbill.append("Check-Out Date: 2025-04-02\t\tTotal Amount: 1000\n");
        txtbill.append("**************************************************************************************************************\n");
        txtbill.append("\t\tThank You, Please Visit Again.");
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtbill = new javax.swing.JTextArea();
        btnprint = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Abox1\\OneDrive\\Pictures\\Hotel Managenment\\cross1.png")); // NOI18N
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton1MouseExited(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 0, 20, 20));

        txtbill.setEditable(false);
        txtbill.setColumns(20);
        txtbill.setRows(5);
        txtbill.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtbillMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(txtbill);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 26, 548, 389));

        btnprint.setBackground(new java.awt.Color(102, 255, 255));
        btnprint.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnprint.setText("Print");
        btnprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprintActionPerformed(evt);
            }
        });
        getContentPane().add(btnprint, new org.netbeans.lib.awtextra.AbsoluteConstraints(238, 421, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Abox1\\OneDrive\\Pictures\\Hotel Managenment\\ManageRoom.jpeg")); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 460));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int yes=JOptionPane.showConfirmDialog(this,"Are You Sure?","Exit",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
        if(yes==JOptionPane.YES_OPTION)
        dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprintActionPerformed
     try {
            // TODO add your handling code here:
            txtbill.print();
        } catch (PrinterException ex) {
            Logger.getLogger(BillPrint.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnprintActionPerformed

    private void txtbillMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtbillMouseClicked
        
    }//GEN-LAST:event_txtbillMouseClicked

    private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseEntered
        // TODO add your handling code here:
            jButton1.setBorder(BorderFactory.createLineBorder(Color.RED, 3)); // Adds a red border

    }//GEN-LAST:event_jButton1MouseEntered

    private void jButton1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseExited
        // TODO add your handling code here:
            jButton1.setBorder(null); // Removes the border when the mouse leaves
    }//GEN-LAST:event_jButton1MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BillPrint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BillPrint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BillPrint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BillPrint.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BillPrint().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnprint;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtbill;
    // End of variables declaration//GEN-END:variables
}
