-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: hotels
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `name` varchar(40) NOT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL,
  `id` char(12) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `indate` date DEFAULT NULL,
  `outdate` date DEFAULT NULL,
  `roomnumber` int NOT NULL,
  `bed` varchar(45) DEFAULT NULL,
  `roomtype` varchar(45) DEFAULT NULL,
  `price` double DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `amount` double DEFAULT NULL,
  `billid` int NOT NULL AUTO_INCREMENT,
  `days` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `billid_UNIQUE` (`billid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('Sonal','9604348761','Female','123456789102','sonalpawar046@gmail.com','2025-04-04','2025-04-04',108,'Double','AC',3500,'check-out',3500,36,1),('Rohit Kumar','6354827712','Male ','364521736738','rohit@gmail.con','2025-04-09','2025-04-09',106,'Single','AC',2000,'check-out',2000,37,1),('Ram Rout','3458784912','Male ','434687654387','ram@123gmail.com','2025-04-02','2025-04-02',105,'Single','NON-AC',1000,'check-out',1000,27,1),('Rahul Rout','3457665647','Male ','458732464734','rahul@123gmail.com','2025-04-01','2025-04-01',104,'Double','NON-AC',2200,'check-out',2200,23,1),('Riya Gorde','1234567898','Female','546568783267','riya@123gmail.com','2025-04-03','2025-04-03',106,'Single','AC',2000,'check-out',2000,35,1),('Priya Mahure','7568234712','Female','647568749123','priya@123gmail.com','2025-04-02','2025-04-02',104,'Double','NON-AC',2200,'check-out',2200,26,1),('Radha Waghmare','7364576234','Female','654783682345','radha@123gmail.com','2025-04-03','2025-04-03',106,'Single','AC',2000,'check-out',2000,32,1),('Rohini Patwal','3464346354','Female','672456482356','rohini@123gmail.com','2025-04-03','2025-06-30',102,'Double','AC',3500,'check-out',308000,33,88),('Sudhir Waghle','3746587342','Male ','734856892384','sudhir@123gmail.com','2025-04-03','2025-04-03',106,'Single','AC',2000,'check-out',2000,28,1),('Madhuri Dixit','7465832766','Female','735487213912','hsgf@634','2025-06-30',NULL,104,'Double','NON-AC',2200,'NULL',NULL,40,NULL),('Vaishnavi Zade','4587346867','Female ','743578739476','vaishnvai@123gmail.com','2025-04-02','2025-04-02',103,'Single','NON-AC',1000,'check-out',1000,25,1),('Sudhir Waghle','6345832761','Male ','763458725617','sudhir@123gmail.com','2025-04-03','2025-04-03',106,'Single','AC',2000,'check-out',2000,31,1),('Rajesh Kumar','3765843279','Male ','763465892573','rajesh@123gmail.com','2025-04-03','2025-04-03',108,'Double','AC',3500,'check-out',3500,34,1),('egyjhb','6523432636','Male ','765428027893','eg@gmail.com','2025-04-09','2025-04-09',107,'Single','AC',2000,'check-out',2000,38,1),('Praniti ','6324583165','Female','765832470912','praniti@123gmail.com','2025-04-03','2025-04-03',103,'Single','NON-AC',1000,'check-out',1000,29,1),('Kalyani Limje','7645783242','Female','867578975289','kalyani@gmail.com','2025-04-09','2025-04-09',112,'Single','AC',2000,'check-out',2000,39,1);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `name` varchar(40) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `sq` varchar(60) NOT NULL,
  `ans` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`email`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES ('','','','',''),('Riya Gorde','riya@gmail.com','567','Your Favourite Game','carrom'),('Shivani','shivani2@gmail.com','456','fev.. game','ball'),('Shweta Sonar','shweta@123gmail.com','12334','Your Favourite Book','Java'),('Shweta Sonar','shweta1@gmail.com','987','Your Favourite Game','Badminton'),('Sonal','sonalpawar046@gmail.com','Sonal@123','Your Favourite Movie','RRR'),('Shweta Sonar','sonar1@gmail.com','678','Your Favourite Book','Java'),('Vaibhavi Kale','vaibhavi@123','8665','Your Favourite Book','Java');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` double DEFAULT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,2000,'Credit Card','2025-04-09 11:06:37'),(2,2000,'Credit Card','2025-04-09 11:09:41'),(3,2000,'Net Banking','2025-04-09 11:12:45'),(4,3500,'UPI','2025-06-30 17:32:55'),(5,3500,'Net Banking','2025-06-30 17:33:20');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `roomnumber` int NOT NULL,
  `roomtype` varchar(45) NOT NULL,
  `bed` varchar(45) NOT NULL,
  `price` double NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`roomnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (101,'AC','Single',2000,'Booked'),(102,'AC','Double',3500,'Available'),(103,'NON-AC','Single',1000,'Available'),(104,'NON-AC','Double',2200,'Booked'),(105,'NON-AC','Single',1000,'Available'),(106,'AC','Single',2000,'Available'),(107,'AC','Single',2000,'Available'),(108,'AC','Double',3500,'Available'),(109,'NON-AC','Single',1000,'Available'),(110,'NON-AC','Double',2200,'Available'),(111,'NON-AC','Double',2200,'Available'),(112,'AC','Single',2000,'Available'),(120,'AC','Single',2000,'Available');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-08 18:45:15
